Whitera1n version 1.0 Readme
by lex

About:
Whitera1n is my one button fimrware 1.0 jailbreak solution. You do not need an internet connection to use Whitera1n.

Requirements:
-A Windows XP or Windows Vista computer
-A USB dock cable
-An iPhone restored to firmware 1.0

Steps:
Step 1) If you have not installed iTunes before, or you have a version older then 7.5, you can just double click the iTunes7.5windowsinstaller.exe. 
If you have a newer version of iTunes, you have to delete the "C:\Documents and Settings\Your User Name\My Documents\My Music\iTunes" directory as well 
as uninstall all Apple Inc. software using control pannel before running the iTunes7.5windowsinstaller.exe. Please note that this will delete ALL 
traces of iTunes previously being on your computer. Either way, follow the instructions in the installer to completion.
Step 2) Double click "Whitera1nFirmware1.0.bat".
Step 3) Follow instructions.

